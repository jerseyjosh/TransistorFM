# TransistorFM

A Python client for interacting with the Transistor.fm API.

## Features

- Client with basic API endpoints.
- API Object typing.

## Installation

Install [Package Name] using pip:

```bash
pip install [package_name]
